NYIMBO YA KUTOTA LESA - GitHub Pages publishing

1. Upload NYIMBO_YA_KUTOTA_LESA_PWA.zip to the ROOT of your existing GitHub repository (not inside a folder).
2. In the repository, tap Add file > Create new file.
3. For the filename, enter exactly:
   .github/workflows/publish-pwa.yml
4. Paste the contents of the supplied publish-pwa.yml file and commit it to the main branch.
5. Open Settings > Pages. Under Build and deployment, set Source to GitHub Actions.
6. Open Actions > Publish NYIMBO YA KUTOTA LESA PWA > Run workflow. If it already ran automatically after commit, wait for it to finish.
7. When the run is green, open Settings > Pages and tap Visit site. The published URL will look like:
   https://YOUR-GITHUB-USERNAME.github.io/nyimbo-ya-kutota-lesa/
8. On Android Chrome, open that URL, tap the three-dot menu, then Install app or Add to Home screen.

Important:
- Replace YOUR-GITHUB-USERNAME with your actual GitHub username only when checking the URL. GitHub Pages sites are public.
- Do not share your GitHub password or verification codes.
- GitHub Pages deployment can take several minutes. Official instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
