NYIMBO YA KUTOTA LESA — INSTALLABLE WEB APP

This is a Progressive Web App (PWA), not an APK. It can be installed from Chrome after it is hosted on an HTTPS website.

EASIEST HOSTING OPTION: GITHUB PAGES
1. Create/open a GitHub repository.
2. Upload the CONTENTS of this folder (index.html, app.js, style.css, manifest.webmanifest, sw.js, icon.svg, data folder and pages folder) to the repository root.
3. In the repository, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch; select the main branch and /(root), then Save.
5. Wait for GitHub Pages to publish. Open the Pages URL on the Android phone in Google Chrome.
6. In Chrome, tap the three-dot menu and choose Install app or Add to Home screen.
7. Open NYIMBO from the new home-screen icon. Keep the first visit online while the app caches the 152 scanned pages for offline use.

CONTENTS
- 152 original scanned page images
- OCR search index (148 pages have OCR text; OCR can contain errors)
- Page browsing, page reader, favourites and search
- Service worker for offline caching

NOTE: Search is OCR-assisted, not a guaranteed perfect transcription. The original scanned page remains authoritative. The initial download may use about 30 MB or more.
