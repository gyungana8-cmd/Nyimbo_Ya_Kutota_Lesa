const CACHE = 'nyimbo-kutota-lesa-v1';
const CORE = ['./','./index.html','./style.css','./app.js','./manifest.webmanifest','./icon.svg','./data/search-index.json'];
const PAGES = Array.from({length:152},(_,i)=>`./pages/p-${String(i+1).padStart(3,'0')}.jpg`);
self.addEventListener('install', event => {
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    await cache.addAll(CORE);
    // Cache each scanned page individually so the full hymnbook is available offline.
    for (const url of PAGES) {
      try { const response=await fetch(url); if(response.ok) await cache.put(url,response); }
      catch (_) { /* continue; pages can be cached when opened later */ }
    }
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => event.waitUntil((async()=>{
  const keys=await caches.keys();
  await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  if(event.request.method!=='GET') return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    const cached=await cache.match(event.request);
    if(cached) return cached;
    try { const response=await fetch(event.request); if(response.ok && new URL(event.request.url).origin===self.location.origin) cache.put(event.request,response.clone()); return response; }
    catch(_){ return new Response('This item is not available offline yet. Connect to the internet and open this page once.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}}); }
  })());
});
